AutoPacker
Made by RainySoft-Team --Rainy101112

Make time: 2023/8/29 12:13
Made with Python

How to use??
##############################################
So first, you need to install Python to your computer.Because this program need Pyinstaller tool
to make Python files to EXE.

And that, run *AutoPacker.exe*.
You will see:
//
Welcome to use AutoPacker!!
[1]Set packer
[2]Transform a .py or a .pyw file to .exe
[3]Close AutoPacker
>>
//
This is a console program. It is very ugly I know...
Type 1 to go to set the packer.
And you will see:
//
Please set a packer...
[1]Pyinstaller
set>
//
OK, now type 1 set packer to Pyinstaller(Yeah there only one because I don't know how to use others).
Now, if you didn't install pyinstaller, Type Y or y to install it with PIP.
And if you installed, Type N or n jump this.

After that, Type 2 to transform files. And you just looking the tips to do it! 
##############################################